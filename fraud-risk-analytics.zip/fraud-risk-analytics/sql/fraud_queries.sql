-- Fraud & Risk Analytics: SQL queries (PostgreSQL syntax)
-- Table: transactions(transaction_id, customer_id, timestamp, merchant_category, amount,
--        txn_country, device_type, card_present, account_age_days, avg_monthly_spend,
--        home_country, is_fraud)

-- 1. Overall fraud KPIs
SELECT COUNT(*)                                   AS total_txns,
       SUM(is_fraud)                              AS fraud_txns,
       ROUND(100.0 * AVG(is_fraud), 2)            AS fraud_rate_pct,
       ROUND(SUM(CASE WHEN is_fraud = 1 THEN amount END)::numeric, 2) AS fraud_loss
FROM transactions;

-- 2. Fraud rate by merchant category (highest risk first)
SELECT merchant_category,
       COUNT(*) AS txns,
       SUM(is_fraud) AS fraud_txns,
       ROUND(100.0 * AVG(is_fraud), 2) AS fraud_rate_pct
FROM transactions
GROUP BY merchant_category
ORDER BY fraud_rate_pct DESC;

-- 3. Velocity check: customers with 3+ transactions inside any 1-hour window
SELECT t1.customer_id,
       t1.timestamp AS window_start,
       COUNT(*)     AS txns_in_1h,
       SUM(t2.amount) AS total_amount
FROM transactions t1
JOIN transactions t2
  ON t1.customer_id = t2.customer_id
 AND t2.timestamp >= t1.timestamp
 AND t2.timestamp <  t1.timestamp + INTERVAL '1 hour'
GROUP BY t1.customer_id, t1.timestamp
HAVING COUNT(*) >= 3
ORDER BY txns_in_1h DESC;

-- 4. Window function: running count of a customer's transactions in the previous hour
SELECT transaction_id, customer_id, timestamp, amount,
       COUNT(*) OVER (
           PARTITION BY customer_id
           ORDER BY timestamp
           RANGE BETWEEN INTERVAL '1 hour' PRECEDING AND CURRENT ROW
       ) - 1 AS prior_txns_1h
FROM transactions;

-- 5. Amount anomaly: transactions more than 3 standard deviations above customer's own mean
WITH stats AS (
    SELECT customer_id, AVG(amount) AS mu, STDDEV(amount) AS sd
    FROM transactions GROUP BY customer_id
)
SELECT t.transaction_id, t.customer_id, t.amount,
       ROUND(((t.amount - s.mu) / NULLIF(s.sd, 0))::numeric, 2) AS z_score
FROM transactions t JOIN stats s USING (customer_id)
WHERE (t.amount - s.mu) / NULLIF(s.sd, 0) > 3
ORDER BY z_score DESC;

-- 6. Impossible-travel proxy: same customer, different countries within 2 hours
SELECT a.customer_id, a.timestamp AS first_txn, b.timestamp AS second_txn,
       a.txn_country AS country_a, b.txn_country AS country_b
FROM transactions a
JOIN transactions b
  ON a.customer_id = b.customer_id
 AND b.timestamp > a.timestamp
 AND b.timestamp <= a.timestamp + INTERVAL '2 hours'
 AND a.txn_country <> b.txn_country;

-- 7. Rule performance: precision & recall of a rule (night + high-risk country)
SELECT COUNT(*) AS flagged,
       SUM(is_fraud) AS true_positives,
       ROUND(100.0 * SUM(is_fraud) / COUNT(*), 2) AS precision_pct,
       ROUND(100.0 * SUM(is_fraud) / (SELECT SUM(is_fraud) FROM transactions), 2) AS recall_pct
FROM transactions
WHERE EXTRACT(HOUR FROM timestamp) BETWEEN 0 AND 4
  AND txn_country IN ('NG', 'RU', 'BR');

-- 8. Monthly fraud trend with month-over-month change
WITH monthly AS (
    SELECT DATE_TRUNC('month', timestamp) AS month,
           ROUND(100.0 * AVG(is_fraud), 3) AS fraud_rate_pct
    FROM transactions GROUP BY 1
)
SELECT month, fraud_rate_pct,
       fraud_rate_pct - LAG(fraud_rate_pct) OVER (ORDER BY month) AS mom_change
FROM monthly ORDER BY month;
