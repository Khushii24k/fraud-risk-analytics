"""End-to-end fraud risk analysis: EDA -> rule engine -> ML model -> business impact.
Run: python src/fraud_analysis.py"""
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, classification_report,
                             confusion_matrix, precision_recall_curve, roc_auc_score)

warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid")
FIG = Path("reports/figures"); FIG.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------ 1. LOAD + QUALITY
df = pd.read_csv("data/transactions.csv", parse_dates=["timestamp"])
print("Rows:", len(df), "| Duplicate IDs:", df.duplicated("transaction_id").sum())
miss = df.isna().sum()
print("Missing values:\n", miss[miss > 0])
df["device_type"] = df["device_type"].fillna("unknown")
print(f"Fraud rate: {df.is_fraud.mean():.2%}  (class imbalance -> use PR-AUC, not accuracy)")

# ------------------------------------------------------------------ 2. FEATURE ENGINEERING
df = df.sort_values(["customer_id", "timestamp"]).reset_index(drop=True)
df["hour"] = df.timestamp.dt.hour
df["is_night"] = df.hour.between(0, 4).astype(int)
df["foreign_txn"] = (df.txn_country != df.home_country).astype(int)
df["high_risk_country"] = df.txn_country.isin(["NG", "RU", "BR"]).astype(int)
df["high_risk_merchant"] = df.merchant_category.isin(["Gift Cards", "Crypto Exchange", "Jewelry", "Electronics"]).astype(int)
df["new_account"] = (df.account_age_days < 90).astype(int)
df["amount_to_avg_ratio"] = df.amount / df.avg_monthly_spend

# velocity: transactions by the same customer in the previous 1 hour
def velocity_1h(g):
    s = pd.Series(1, index=g.timestamp)
    return s.rolling("1h").sum().values - 1
df["txn_count_1h"] = np.concatenate([velocity_1h(g) for _, g in df.groupby("customer_id", sort=False)])

# ------------------------------------------------------------------ 3. EDA CHARTS
fig, ax = plt.subplots(2, 2, figsize=(13, 9))
df.groupby("hour").is_fraud.mean().mul(100).plot(kind="bar", ax=ax[0, 0], color="#c0392b")
ax[0, 0].set(title="Fraud Rate by Hour of Day", ylabel="Fraud rate (%)")
df.groupby("merchant_category").is_fraud.mean().mul(100).sort_values().plot(kind="barh", ax=ax[0, 1], color="#2c3e50")
ax[0, 1].set(title="Fraud Rate by Merchant Category", xlabel="Fraud rate (%)")
df.groupby("txn_country").is_fraud.mean().mul(100).sort_values().plot(kind="barh", ax=ax[1, 0], color="#e67e22")
ax[1, 0].set(title="Fraud Rate by Transaction Country", xlabel="Fraud rate (%)")
sns.boxplot(data=df, x="is_fraud", y="amount", showfliers=False, ax=ax[1, 1], palette=["#27ae60", "#c0392b"])
ax[1, 1].set(title="Amount: Legit (0) vs Fraud (1)")
plt.tight_layout(); plt.savefig(FIG / "01_eda_fraud_patterns.png", dpi=140); plt.close()

# ------------------------------------------------------------------ 4. RULE-BASED ENGINE
rules = {
    "R1_high_amount (>2500)": df.amount > 2500,
    "R2_night_txn (0-4h)": df.is_night == 1,
    "R3_high_risk_country_foreign": (df.foreign_txn == 1) & (df.high_risk_country == 1),
    "R4_velocity (>=3 txns/1h)": df.txn_count_1h >= 3,
    "R5_new_acct_high_risk_merchant": (df.new_account == 1) & (df.high_risk_merchant == 1),
    "R6_card_not_present_big_ratio": (df.card_present == 0) & (df.amount_to_avg_ratio > 0.5),
}
rows = []
for name, m in rules.items():
    tp = int((m & (df.is_fraud == 1)).sum()); fp = int((m & (df.is_fraud == 0)).sum())
    rows.append({"rule": name, "flagged": int(m.sum()), "true_fraud": tp, "false_pos": fp,
                 "precision": round(tp / max(m.sum(), 1), 3),
                 "recall": round(tp / df.is_fraud.sum(), 3)})
rule_perf = pd.DataFrame(rows)
rule_perf.to_csv("reports/rule_performance.csv", index=False)
print("\nRule performance:\n", rule_perf.to_string(index=False))

weights = dict(zip(rules, [20, 10, 25, 25, 15, 10]))
df["rule_score"] = sum(m.astype(int) * weights[n] for n, m in rules.items())
df["risk_tier"] = pd.cut(df.rule_score, [-1, 9, 29, 49, 200], labels=["Low", "Medium", "High", "Critical"])
tier = df.groupby("risk_tier", observed=True).agg(txns=("is_fraud", "size"), fraud=("is_fraud", "sum"),
                                                 fraud_rate=("is_fraud", "mean")).round(4)
print("\nRisk tiers:\n", tier)
tier.to_csv("reports/risk_tier_summary.csv")

# ------------------------------------------------------------------ 5. ML MODEL
features = ["amount", "hour", "is_night", "foreign_txn", "high_risk_country", "high_risk_merchant",
            "new_account", "amount_to_avg_ratio", "txn_count_1h", "card_present", "account_age_days"]
cutoff = df.timestamp.quantile(0.75)               # time-based split avoids leakage
train, test = df[df.timestamp <= cutoff], df[df.timestamp > cutoff]
Xtr, ytr, Xte, yte = train[features], train.is_fraud, test[features], test.is_fraud

lr = LogisticRegression(max_iter=2000, class_weight="balanced").fit((Xtr - Xtr.mean()) / Xtr.std(), ytr)
gb = GradientBoostingClassifier(n_estimators=200, max_depth=3, learning_rate=0.08, random_state=42).fit(Xtr, ytr)
p_lr = lr.predict_proba((Xte - Xtr.mean()) / Xtr.std())[:, 1]
p_gb = gb.predict_proba(Xte)[:, 1]
metrics = pd.DataFrame({
    "model": ["Logistic Regression", "Gradient Boosting", "Rule engine score"],
    "ROC_AUC": [roc_auc_score(yte, p) for p in (p_lr, p_gb, test.rule_score)],
    "PR_AUC": [average_precision_score(yte, p) for p in (p_lr, p_gb, test.rule_score)]}).round(3)
print("\nModel comparison:\n", metrics.to_string(index=False))
metrics.to_csv("reports/model_metrics.csv", index=False)

# threshold selection driven by business cost
REVIEW_COST = 15.0          # cost per manual review; missed fraud loses the txn amount
best = None
for t in np.arange(0.05, 0.95, 0.01):
    flag = p_gb >= t
    missed = test.loc[(~flag) & (yte == 1), "amount"].sum()
    review = flag.sum() * REVIEW_COST
    cost = missed + review
    if best is None or cost < best[1]:
        best = (t, cost, missed, review, flag)
t, cost, missed, review, flag = best
baseline = test.loc[yte == 1, "amount"].sum()
print(f"\nOptimal threshold: {t:.2f}")
print(classification_report(yte, flag, target_names=["legit", "fraud"], digits=3))
print("Confusion matrix:\n", confusion_matrix(yte, flag))
print(f"No-model fraud loss: {baseline:,.0f} | With model (missed + review cost): {cost:,.0f} "
      f"| Savings: {baseline - cost:,.0f} ({(baseline - cost) / baseline:.1%})")
pd.DataFrame({"threshold": [round(t, 2)], "no_model_loss": [round(baseline)], "missed_fraud_loss": [round(missed)],
              "review_cost": [round(review)], "net_savings": [round(baseline - cost)]}).to_csv("reports/business_impact.csv", index=False)

# ------------------------------------------------------------------ 6. MODEL CHARTS
fig, ax = plt.subplots(1, 2, figsize=(13, 5))
for name, p in [("Gradient Boosting", p_gb), ("Logistic Reg.", p_lr)]:
    pr, rc, _ = precision_recall_curve(yte, p)
    ax[0].plot(rc, pr, label=f"{name} (PR-AUC={average_precision_score(yte, p):.2f})")
ax[0].set(title="Precision-Recall Curve", xlabel="Recall", ylabel="Precision"); ax[0].legend()
imp = pd.Series(gb.feature_importances_, index=features).sort_values()
imp.plot(kind="barh", ax=ax[1], color="#2c3e50"); ax[1].set(title="Feature Importance (Gradient Boosting)")
plt.tight_layout(); plt.savefig(FIG / "02_model_performance.png", dpi=140); plt.close()

fig, ax = plt.subplots(figsize=(7, 4.5))
tier.fraud_rate.mul(100).plot(kind="bar", ax=ax, color=["#27ae60", "#f1c40f", "#e67e22", "#c0392b"][:len(tier)])
ax.set(title="Fraud Rate by Rule-Based Risk Tier", ylabel="Fraud rate (%)", xlabel="")
plt.xticks(rotation=0); plt.tight_layout(); plt.savefig(FIG / "03_risk_tiers.png", dpi=140); plt.close()

# ------------------------------------------------------------------ 7. ALERT QUEUE FOR ANALYSTS
alerts = test.assign(model_score=p_gb)[flag].sort_values("model_score", ascending=False)
alerts[["transaction_id", "customer_id", "timestamp", "amount", "merchant_category", "txn_country",
        "rule_score", "model_score", "is_fraud"]].head(200).to_csv("reports/analyst_alert_queue_top200.csv", index=False)
print("\nDone. Outputs saved to /reports")
