"""Generate a realistic synthetic card-transaction dataset with injected fraud patterns.
No real customer data is used. Run: python src/generate_data.py"""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
N = 60_000
N_CUST = 5_000

MERCHANTS = ["Grocery", "Fuel", "Restaurant", "Electronics", "Travel", "Online Retail",
             "Pharmacy", "Entertainment", "Jewelry", "Gift Cards", "Crypto Exchange"]
COUNTRIES = ["IN", "US", "GB", "AE", "SG", "NG", "RU", "BR"]
DEVICES = ["mobile", "desktop", "pos_terminal", "atm"]

cust = pd.DataFrame({
    "customer_id": np.arange(N_CUST),
    "account_age_days": rng.integers(10, 4000, N_CUST),
    "avg_monthly_spend": rng.lognormal(8.5, 0.6, N_CUST).round(2),
    "home_country": rng.choice(["IN", "US", "GB"], N_CUST, p=[0.7, 0.2, 0.1]),
})

df = pd.DataFrame({
    "transaction_id": np.arange(N),
    "customer_id": rng.integers(0, N_CUST, N),
    "timestamp": pd.Timestamp("2026-01-01") + pd.to_timedelta(rng.integers(0, 180 * 86400, N), unit="s"),
    "merchant_category": rng.choice(MERCHANTS, N, p=[.22, .12, .16, .08, .06, .14, .06, .06, .03, .03, .04]),
    "amount": rng.lognormal(6.0, 1.0, N).round(2),
    "txn_country": rng.choice(COUNTRIES, N, p=[.68, .12, .06, .05, .03, .02, .02, .02]),
    "device_type": rng.choice(DEVICES, N, p=[.35, .25, .35, .05]),
})
df["card_present"] = df["device_type"].isin(["pos_terminal", "atm"]).astype(int)
df = df.merge(cust, on="customer_id")

# ---- inject fraud via a latent risk score ----
hour = df["timestamp"].dt.hour
risk = (
    -6.0
    + 1.4 * (df["amount"] > 2500)
    + 1.1 * hour.between(0, 4)
    + 1.6 * ((df["txn_country"] != df["home_country"]) & df["txn_country"].isin(["NG", "RU", "BR"]))
    + 0.9 * df["merchant_category"].isin(["Gift Cards", "Crypto Exchange", "Jewelry", "Electronics"])
    + 1.0 * (df["card_present"] == 0)
    + 0.8 * (df["account_age_days"] < 90)
)
df["is_fraud"] = (rng.random(len(df)) < 1 / (1 + np.exp(-risk))).astype(int)

# fraud amounts skew higher
mask = df["is_fraud"] == 1
df.loc[mask, "amount"] = (df.loc[mask, "amount"] * rng.uniform(1.5, 4, mask.sum())).round(2)

# velocity burst: some compromised cards used many times in a short window
burst_cust = rng.choice(N_CUST, 40, replace=False)
rows = []
for c in burst_cust:
    t0 = pd.Timestamp("2026-01-01") + pd.to_timedelta(int(rng.integers(0, 170 * 86400)), unit="s")
    for k in range(int(rng.integers(5, 12))):
        rows.append({"customer_id": c,
                     "timestamp": t0 + pd.to_timedelta(int(rng.integers(0, 900)), unit="s"),
                     "merchant_category": rng.choice(["Online Retail", "Gift Cards", "Electronics"]),
                     "amount": round(float(rng.uniform(200, 1800)), 2),
                     "txn_country": rng.choice(["NG", "RU", "BR"]),
                     "device_type": "desktop", "card_present": 0, "is_fraud": 1})
burst = pd.DataFrame(rows).merge(cust, on="customer_id")
df = pd.concat([df, burst], ignore_index=True).sort_values("timestamp").reset_index(drop=True)
df["transaction_id"] = np.arange(len(df))

# introduce a little missing data (realistic data-quality issue)
df.loc[rng.choice(len(df), 300, replace=False), "device_type"] = np.nan

Path("data").mkdir(exist_ok=True)
df.to_csv("data/transactions.csv", index=False)
print(f"Saved {len(df):,} transactions | fraud rate: {df.is_fraud.mean():.2%}")
